# CodeAlpha_ObjectDetectionTracking

Task 4 of the **CodeAlpha Artificial Intelligence Internship** — real-time
object detection and tracking using a pretrained **YOLOv8** model for
detection and a **from-scratch SORT** tracker (Kalman filter + Hungarian/IOU
matching) for tracking.

## How it works

1. **Detection** — each video frame is passed to a pretrained YOLOv8 model
   (`ultralytics`), which returns bounding boxes, confidence scores, and
   class labels (80 COCO classes: person, car, dog, etc.).
2. **Tracking** — the boxes are handed to a SORT tracker built from scratch
   in `src/sort.py`:
   - each tracked object is a **Kalman filter** predicting its next
     position assuming constant velocity
   - each frame, predicted tracks are matched to new detections by
     **IOU (intersection-over-union)** using the **Hungarian algorithm**
     (`scipy.optimize.linear_sum_assignment`)
   - unmatched detections start new tracks; tracks with no match for too
     long (`--max-age`) are dropped
3. **Display** — bounding boxes, a persistent track ID, and the class
   label are drawn on each frame in real time, along with a live FPS
   counter.

## Project structure

```
requirements.txt
src/
  detector.py   # YOLOv8 wrapper: frame -> [x1,y1,x2,y2,confidence] + labels
  sort.py       # SORT tracker built from scratch (Kalman filter + IOU/Hungarian matching)
  main.py       # video/webcam loop tying detection + tracking together
output/         # saved annotated videos land here (if --output is used)
```

## Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Requires Python 3.10+. The first run downloads the YOLOv8-nano weights
(`yolov8n.pt`, ~6 MB) automatically — an internet connection is needed
once for that.

## Running it

```bash
# Webcam (default camera)
python src/main.py

# A specific webcam (if you have more than one)
python src/main.py --source 1

# A video file instead of a webcam
python src/main.py --source path/to/video.mp4

# Save the annotated result instead of / as well as previewing it
python src/main.py --source video.mp4 --output output/tracked.mp4

# Only track people (COCO class 0) — useful for crowd/foot-traffic footage
python src/main.py --classes 0

# Run without opening a preview window (e.g. on a headless server)
python src/main.py --source video.mp4 --output output/tracked.mp4 --no-display
```

Press **`q`** in the preview window to stop. Useful COCO class IDs:
`0` person, `2` car, `15` cat, `16` dog, `39` bottle — the full list is in
`detector.py`'s loaded model (`detector.class_names`), or search "COCO 80
classes" for a reference table.

## Tuning the tracker

- `--max-age` — how many frames a track survives with no matching
  detection (handles brief occlusions; higher = more tolerant, but can
  merge separate objects after a long gap)
- `--min-hits` — how many consecutive matches are required before a track
  is drawn (filters out one-frame false positives; higher = more stable
  but slower to pick up new objects)
- `--iou-threshold` — how much overlap is required to count as a match
  (lower = more lenient matching, useful for fast-moving objects)
- `--conf` — YOLO detection confidence threshold

## Notes on scope

YOLOv8-nano is used by default for real-time CPU performance; for higher
accuracy (at the cost of speed), swap `--weights yolov8n.pt` for
`yolov8s.pt`, `yolov8m.pt`, etc. — `ultralytics` downloads whichever
checkpoint you name automatically.

## Author

Built as part of the CodeAlpha Artificial Intelligence Internship.
