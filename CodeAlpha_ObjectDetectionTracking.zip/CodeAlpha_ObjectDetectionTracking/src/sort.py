"""
sort.py

A from-scratch implementation of SORT (Simple Online and Realtime
Tracking): each tracked object is a constant-velocity Kalman filter over
[center_x, center_y, scale(area), aspect_ratio], and detections are
assigned to existing tracks frame-by-frame using IOU (intersection-over-
union) cost with the Hungarian algorithm (scipy.optimize.linear_sum_assignment).

Usage:
    tracker = Sort(max_age=15, min_hits=3, iou_threshold=0.3)
    tracked_objects = tracker.update(detections)  # detections: (N, 5) [x1,y1,x2,y2,conf]
    # tracked_objects: (M, 5) [x1, y1, x2, y2, track_id]
"""

import numpy as np
from scipy.optimize import linear_sum_assignment


def bbox_to_state(bbox: np.ndarray) -> np.ndarray:
    """[x1, y1, x2, y2] -> [center_x, center_y, area, aspect_ratio]"""
    x1, y1, x2, y2 = bbox[:4]
    w, h = x2 - x1, y2 - y1
    cx, cy = x1 + w / 2.0, y1 + h / 2.0
    area = max(w * h, 1e-6)
    aspect_ratio = w / max(h, 1e-6)
    return np.array([cx, cy, area, aspect_ratio])


def state_to_bbox(state: np.ndarray) -> np.ndarray:
    """[center_x, center_y, area, aspect_ratio] -> [x1, y1, x2, y2]"""
    cx, cy, area, aspect_ratio = state[:4]
    area = max(area, 1e-6)
    w = np.sqrt(area * aspect_ratio)
    h = area / max(w, 1e-6)
    return np.array([cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0])


def iou(bbox_a: np.ndarray, bbox_b: np.ndarray) -> float:
    """Intersection-over-union of two [x1, y1, x2, y2] boxes."""
    x1 = max(bbox_a[0], bbox_b[0])
    y1 = max(bbox_a[1], bbox_b[1])
    x2 = min(bbox_a[2], bbox_b[2])
    y2 = min(bbox_a[3], bbox_b[3])

    inter_w = max(0.0, x2 - x1)
    inter_h = max(0.0, y2 - y1)
    intersection = inter_w * inter_h

    area_a = max(0.0, bbox_a[2] - bbox_a[0]) * max(0.0, bbox_a[3] - bbox_a[1])
    area_b = max(0.0, bbox_b[2] - bbox_b[0]) * max(0.0, bbox_b[3] - bbox_b[1])
    union = area_a + area_b - intersection

    return intersection / union if union > 0 else 0.0


class KalmanBoxTracker:
    """A single tracked object: constant-velocity Kalman filter over
    [cx, cy, area, aspect_ratio, v_cx, v_cy, v_area]. Aspect ratio is
    assumed roughly constant frame-to-frame (no velocity term for it),
    matching the classic SORT formulation.
    """

    _next_id = 1

    def __init__(self, bbox: np.ndarray):
        # State transition: constant velocity on cx, cy, area.
        self.F = np.eye(7)
        for i in range(3):
            self.F[i, i + 4] = 1.0

        # Measurement matrix: we only observe [cx, cy, area, aspect_ratio].
        self.H = np.zeros((4, 7))
        for i in range(4):
            self.H[i, i] = 1.0

        # Process/measurement noise (tuned for typical video frame rates).
        self.Q = np.eye(7) * 1.0
        self.Q[4:, 4:] *= 0.01  # velocities change slowly
        self.R = np.eye(4) * 1.0
        self.P = np.eye(7) * 10.0

        self.x = np.zeros(7)
        self.x[:4] = bbox_to_state(bbox)

        self.id = KalmanBoxTracker._next_id
        KalmanBoxTracker._next_id += 1

        self.time_since_update = 0
        self.hits = 0
        self.hit_streak = 0
        self.age = 0

    def predict(self) -> np.ndarray:
        if self.x[6] + self.x[2] <= 0:  # prevent area from going negative
            self.x[6] = 0.0

        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q

        self.age += 1
        if self.time_since_update > 0:
            self.hit_streak = 0
        self.time_since_update += 1

        return state_to_bbox(self.x)

    def update(self, bbox: np.ndarray):
        z = bbox_to_state(bbox)
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)

        self.x = self.x + K @ y
        self.P = (np.eye(7) - K @ self.H) @ self.P

        self.time_since_update = 0
        self.hits += 1
        self.hit_streak += 1

    def get_state(self) -> np.ndarray:
        return state_to_bbox(self.x)


def associate_detections_to_trackers(
    detections: np.ndarray, predicted_boxes: np.ndarray, iou_threshold: float
):
    """Match detections to predicted tracker boxes via the Hungarian
    algorithm on an IOU cost matrix.

    Returns (matches, unmatched_detections, unmatched_trackers), where
    matches is an (M, 2) array of [detection_index, tracker_index].
    """
    if len(predicted_boxes) == 0:
        return np.empty((0, 2), dtype=int), np.arange(len(detections)), np.empty(0, dtype=int)

    iou_matrix = np.zeros((len(detections), len(predicted_boxes)), dtype=np.float32)
    for d, det in enumerate(detections):
        for t, trk in enumerate(predicted_boxes):
            iou_matrix[d, t] = iou(det, trk)

    row_idx, col_idx = linear_sum_assignment(-iou_matrix)

    matches, unmatched_detections, unmatched_trackers = [], [], []

    for d in range(len(detections)):
        if d not in row_idx:
            unmatched_detections.append(d)
    for t in range(len(predicted_boxes)):
        if t not in col_idx:
            unmatched_trackers.append(t)

    for d, t in zip(row_idx, col_idx):
        if iou_matrix[d, t] < iou_threshold:
            unmatched_detections.append(d)
            unmatched_trackers.append(t)
        else:
            matches.append([d, t])

    matches = np.array(matches) if matches else np.empty((0, 2), dtype=int)
    return matches, np.array(unmatched_detections), np.array(unmatched_trackers)


class Sort:
    def __init__(self, max_age: int = 15, min_hits: int = 3, iou_threshold: float = 0.3):
        """
        max_age: frames to keep a track alive without a matching detection
                 before dropping it (handles brief occlusions).
        min_hits: consecutive matched frames required before a track is
                  reported (filters out one-off false detections).
        iou_threshold: minimum IOU for a detection-to-track match.
        """
        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.trackers: list[KalmanBoxTracker] = []
        self.frame_count = 0

    def update(self, detections: np.ndarray) -> np.ndarray:
        """
        detections: (N, 5) array [x1, y1, x2, y2, confidence]. Pass an
                    empty (0, 5) array on frames with no detections.

        Returns: (M, 5) array [x1, y1, x2, y2, track_id]
        """
        self.frame_count += 1

        predicted_boxes = np.array([t.predict() for t in self.trackers]) if self.trackers else np.empty((0, 4))

        matches, unmatched_dets, unmatched_trks = associate_detections_to_trackers(
            detections, predicted_boxes, self.iou_threshold
        )

        for d, t in matches:
            self.trackers[t].update(detections[d])

        for d in unmatched_dets:
            self.trackers.append(KalmanBoxTracker(detections[d]))

        results = []
        for tracker in self.trackers:
            if tracker.time_since_update < 1 and (
                tracker.hit_streak >= self.min_hits or self.frame_count <= self.min_hits
            ):
                bbox = tracker.get_state()
                results.append(np.concatenate((bbox, [tracker.id])))

        # Drop trackers that haven't matched in too long.
        self.trackers = [t for t in self.trackers if t.time_since_update <= self.max_age]

        return np.array(results) if results else np.empty((0, 5))
