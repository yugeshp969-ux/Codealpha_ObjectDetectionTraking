"""
detector.py

Thin wrapper around a pretrained YOLOv8 model (via the `ultralytics`
package) that turns one video frame into a list of detections in the
format the SORT tracker expects: [x1, y1, x2, y2, confidence].
"""

import numpy as np
from ultralytics import YOLO


class Detector:
    def __init__(self, weights: str = "yolov8n.pt", conf_threshold: float = 0.4,
                 classes: list[int] | None = None):
        """
        weights: path or name of a YOLOv8 checkpoint. "yolov8n.pt" (nano)
                 is downloaded automatically on first run and is fast
                 enough for real-time webcam use on a CPU.
        conf_threshold: minimum detection confidence to keep.
        classes: optional list of COCO class indices to restrict detection
                 to (e.g. [0] for "person" only). None = detect everything.
        """
        self.model = YOLO(weights)
        self.conf_threshold = conf_threshold
        self.classes = classes
        self.class_names = self.model.names  # dict: class_id -> label

    def detect(self, frame: np.ndarray) -> tuple[np.ndarray, list[str]]:
        """
        Runs detection on a single BGR frame (as read by OpenCV).

        Returns:
            detections: (N, 5) array of [x1, y1, x2, y2, confidence]
            labels: list of N class-name strings, same order as detections
        """
        results = self.model.predict(
            frame,
            conf=self.conf_threshold,
            classes=self.classes,
            verbose=False,
        )[0]

        if results.boxes is None or len(results.boxes) == 0:
            return np.empty((0, 5)), []

        boxes = results.boxes.xyxy.cpu().numpy()
        confs = results.boxes.conf.cpu().numpy()
        class_ids = results.boxes.cls.cpu().numpy().astype(int)

        detections = np.hstack((boxes, confs.reshape(-1, 1)))
        labels = [self.class_names[c] for c in class_ids]

        return detections, labels
