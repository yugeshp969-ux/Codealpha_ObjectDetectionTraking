"""
main.py

Real-time object detection and tracking: reads frames from a webcam or a
video file, runs YOLOv8 detection on each frame, feeds the detections into
the SORT tracker, and draws bounding boxes with persistent track IDs.

Usage:
    python src/main.py                          # default webcam
    python src/main.py --source 1                # a different webcam index
    python src/main.py --source path/to/video.mp4
    python src/main.py --source video.mp4 --output output/tracked.mp4
    python src/main.py --classes 0                # track only "person"
"""

import argparse
import time

import cv2
import numpy as np

from detector import Detector
from sort import Sort

# A fixed color per track ID (cycled) so the same object keeps the same
# color across frames, making it easy to follow visually.
COLORS = [
    (255, 99, 71), (60, 179, 113), (65, 105, 225), (238, 130, 238),
    (255, 215, 0), (0, 206, 209), (255, 140, 0), (154, 205, 50),
]


def parse_args():
    parser = argparse.ArgumentParser(description="Real-time object detection and tracking.")
    parser.add_argument("--source", default="0", help="Webcam index (e.g. 0) or path to a video file")
    parser.add_argument("--weights", default="yolov8n.pt", help="YOLOv8 checkpoint to use")
    parser.add_argument("--conf", type=float, default=0.4, help="Detection confidence threshold")
    parser.add_argument("--classes", type=int, nargs="*", default=None,
                         help="Restrict detection to these COCO class IDs (e.g. --classes 0 2 for person, car)")
    parser.add_argument("--max-age", type=int, default=15, help="SORT: frames to keep a lost track alive")
    parser.add_argument("--min-hits", type=int, default=3, help="SORT: matches required before showing a track")
    parser.add_argument("--iou-threshold", type=float, default=0.3, help="SORT: IOU match threshold")
    parser.add_argument("--output", default=None, help="Optional path to save the annotated video")
    parser.add_argument("--no-display", action="store_true", help="Don't open a preview window (headless)")
    return parser.parse_args()


def open_source(source: str) -> cv2.VideoCapture:
    # A pure digit string means "use this webcam index"; anything else is
    # treated as a file path.
    cam_index = int(source) if source.isdigit() else None
    cap = cv2.VideoCapture(cam_index if cam_index is not None else source)
    if not cap.isOpened():
        raise SystemExit(f"Could not open video source: {source}")
    return cap


def draw_tracks(frame: np.ndarray, tracks: np.ndarray, labels_by_id: dict):
    for x1, y1, x2, y2, track_id in tracks:
        track_id = int(track_id)
        color = COLORS[track_id % len(COLORS)]
        p1, p2 = (int(x1), int(y1)), (int(x2), int(y2))

        cv2.rectangle(frame, p1, p2, color, 2)

        label = labels_by_id.get(track_id, "object")
        text = f"ID {track_id} · {label}"
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(frame, (p1[0], p1[1] - th - 8), (p1[0] + tw + 6, p1[1]), color, -1)
        cv2.putText(frame, text, (p1[0] + 3, p1[1] - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)


def main():
    args = parse_args()

    detector = Detector(weights=args.weights, conf_threshold=args.conf, classes=args.classes)
    tracker = Sort(max_age=args.max_age, min_hits=args.min_hits, iou_threshold=args.iou_threshold)

    cap = open_source(args.source)
    fps_source = cap.get(cv2.CAP_PROP_FPS) or 30
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    writer = None
    if args.output:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(args.output, fourcc, fps_source, (width, height))
        print(f"Saving annotated output to {args.output}")

    prev_time = time.time()
    frame_count = 0

    print("Press 'q' in the preview window to quit." if not args.no_display else "Running headless — Ctrl+C to stop.")

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_count += 1

            detections, det_labels = detector.detect(frame)
            tracks = tracker.update(detections if len(detections) else np.empty((0, 5)))

            # Map each live track ID to its most recent detection label by
            # matching current detections to tracked boxes via IOU, so the
            # on-screen text shows a class name, not just an ID number.
            labels_by_id = {}
            if len(tracks) and len(detections):
                from sort import iou as _iou
                for x1, y1, x2, y2, track_id in tracks:
                    best_iou, best_label = 0.0, None
                    for det, label in zip(detections, det_labels):
                        score = _iou(np.array([x1, y1, x2, y2]), det[:4])
                        if score > best_iou:
                            best_iou, best_label = score, label
                    if best_label:
                        labels_by_id[int(track_id)] = best_label

            draw_tracks(frame, tracks, labels_by_id)

            now = time.time()
            fps = 1.0 / max(now - prev_time, 1e-6)
            prev_time = now
            cv2.putText(frame, f"FPS: {fps:.1f}  Tracks: {len(tracks)}", (10, 24),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)

            if writer:
                writer.write(frame)

            if not args.no_display:
                cv2.imshow("Object Detection & Tracking — press q to quit", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        if writer:
            writer.release()
        cv2.destroyAllWindows()
        print(f"Processed {frame_count} frame(s).")


if __name__ == "__main__":
    main()
